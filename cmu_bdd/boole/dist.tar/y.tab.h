
typedef union 
{
  st_entry e;
  bdd f;
  assoc a;
  vec v;
  long i;
} YYSTYPE;
extern YYSTYPE yylval;
# define UNKNOWNCHAR 257
# define ID 258
# define NEWID 259
# define NUM 260
# define CLEAR 261
# define ALL 262
# define FUNCPROFILE 263
# define GC 264
# define LIMIT 265
# define PRINT 266
# define PRINTSOP 267
# define PROFILE 268
# define REORDER 269
# define SIFT 270
# define WINDOW 271
# define HYBRID 272
# define NONE 273
# define SATISFY 274
# define SATISFYSUPPORT 275
# define SATISFYFRACTION 276
# define SIZE 277
# define STATS 278
# define TIMER 279
# define OFF 280
# define VARS 281
# define AGETS 282
# define GETS 283
# define EXISTS 284
# define FORALL 285
# define SUBST 286
